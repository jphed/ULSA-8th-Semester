import UIKit

let celsius = 20.0
var fahreinheit = (celsius * 9.0 / 5.0) + 32.0
print("grados en celsius", celsius)
print("grados en fahrenheit", fahreinheit)
